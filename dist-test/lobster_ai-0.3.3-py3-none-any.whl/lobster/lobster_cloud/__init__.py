"""
Lobster Cloud - Cloud client for Lobster AI
"""

__version__ = "0.1.0"

from .client import CloudLobsterClient

__all__ = ["CloudLobsterClient"]
