"""
GEO metadata handling submodule.

Provides metadata fetching, extraction, and validation functionality.
"""

# Placeholder - will be populated when extracting from geo_service.py
