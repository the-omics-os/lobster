"""
GEO utility functions submodule.

Provides URL classification and file pattern utilities.
"""

# Placeholder - will be populated when extracting from geo_service.py
