"""Lobster OS UI Services."""

from .error_service import ErrorService, ErrorCategory

__all__ = ["ErrorService", "ErrorCategory"]
